package com.otp.springbootauthgoogle;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @GetMapping("/")
    public String Hello(){
        return "Hello Student Welcome your Dashboard";
    }
}
